# DAG Tails — combined counsel review pack

**Status:** Working file for counsel. **Not legal advice.** Not an executed opinion, clearance, privacy policy, or assignment.

**Product:** DAG Tails (bartending game)  
**Operator (placeholder):** DAG.com, operating DAG Tails  
**Live beta:** https://dag-com.github.io/dagtails/  
**Repo:** https://github.com/dag-com/dagtails  
**Packed:** 2026-09-06

Open **01-COVER-AND-ASKS.md** first. That file is the approval checklist.

This pack is assembled by `node docs/legal/pack-counsel-review.js`.
