# What we need counsel to approve

This is a clearance and documents pack for a **private beta** of a web bartending game. Please treat every “cleared_keep” note from the in-house scanner as **engineering hygiene**, not a lawyer opinion.

## A. Please return

1. Which items below are **ok for a closed beta**, which must **change before beta**, and which can wait for a **store / public launch**.
2. Marked-up or replacement text for:
   - Privacy notice
   - Beta-tester email
   - In-game cocktail / recipe **IP assignment**
3. Whether the **DAG Tails** wordmark and duck mascot are clear enough to keep, and what to file (if anything) for trademark.
4. Governing law, company legal name, address, and contact for the notice.

## B. Approval checklist

### 1. House brand

| Item | In the live game? | Ask |
|---|---|---|
| Wordmark **DAG Tails** / **DAG TAILS** | Yes — logo, splash, hub | Clearance to use; search/file classes (games, entertainment, maybe later merch). Watch **Bacardi** Madrid IR 1572190 (feathers + the word TAILS, cl. 32/33) if we ever put TAILS on drinks goods. |
| Duck mascot (hoodie / service jacket / Ace bomber) | Yes — `brand-images/` | Original character? Any Disney DuckTales-like trade dress left? (Old painted gold-brush wordmarks were deleted.) |
| Ace gold teardrop **aviators** | Yes — Ace rank still | HIGH: Ray-Ban Aviator trade dress. Change frame shape / drop temple logos before a commercial launch? |
| Wavy white **sneaker sidestripe** on Ace | Yes — live Ace shoes | Ship-stopper watch: Vans sidestripe trade dress. Recolor or drop the wave? |
| Invented DAG patches on the bomber | Yes | Keep if original. |

### 2. Do not ship / not in the live pack (confirm they stay out)

| Item | Status | Ask |
|---|---|---|
| Top Gun / Maverick jacket study (name tapes, patches) | Quarantined under `mocks/` — **not** copied into `assets/` | Confirm: never ship, never composite onto Ace. |
| Old DuckTales-like painted title explorations | Deleted from the live splash | Confirm live logo in `brand-images/dag-tails-logo.png` is far enough from Disney gold-brush + teal 3D + feather underline. |
| Horse / K9 / ape mascot studies | `mocks/mascot-alts/` only | Confirm: mocks-only is enough; do not put them on hub/map. |

### 3. Cocktail, venue, and ingredient names (live catalog)

See `catalog/NAMES.md`. In-house notes (not a clearance):

| Topic | In-house note | Ask |
|---|---|---|
| IBA-style classics (Negroni, Daiquiri, Mai Tai, …) | Kept as **recipe titles**, generic bottles | Ok as game content? Any we must rename? |
| Shirley Temple / Roy Rogers | On the **under-18 mocktail** path | HIGH: celebrity names in a kids-facing menu. Rename (Cherry Fizz / Cola Cherry) for beta or only for public launch? |
| Casa Caña | Invented Havana rum bar (replaced a real landmark) | Confirm invented name is ok. |
| Red Bitter / Bitter Orange Aperitivo | Genericized; not Campari/Aperol house marks | Confirm. |
| Angostura Bitters | House bitters mark, common bar term | Keep or say “aromatic bitters”? |
| Drambuie | In the ingredient rail | Keep generic “honeyed Scotch liqueur”? |
| Godfather / Aviation / Sazerac | Recipe titles; film / gin brand / company overlap | Ok as titles if no logos? |
| Sex and the City / The Dude lore in origin blurbs | Flavor text on some classics | Strip celebrity/film catchphrases? |

Names we already **refuse** (scanner ship-stoppers): Dark ’n’ Stormy / Gosling, Painkiller / Pusser’s, El Floridita / Hemingway. Please confirm that list.

### 4. Privacy, children, international transfers

Files: `privacy/`

| Topic | Current draft | Ask |
|---|---|---|
| Privacy notice | Placeholder HTML + markdown, linked from create-user and the beta door | Replace with an in-force notice. |
| Consent checkbox | Required before email OTP send and before profile save | Is a checkbox enough for beta? |
| Public alias vs private name | Only alias is written to public `players.name` | Confirm. |
| Optional location | Still public on streak leaderboard if typed | Hide for beta? |
| Age field | Allows 1–120; alcohol menu is 18+; mocktails under 18 | COPPA / kid GDPR: should beta **refuse under 18** entirely? |
| Hosts | GitHub Pages + Supabase (may be outside the player’s country) | Lawful basis / SCC / UK GDPR / CCPA language. |
| Analytics | Play events, device id, underage flag — no private name/email in the public report | Confirm. |

### 5. Player-created cocktails (IP)

Placeholder in the privacy notice: every in-game cocktail, recipe, name, garnish, and Community share is **property of the operator**; the player gets a limited play licence.

Ask: is an in-game checkbox assignment **enforceable** for a beta? Do we need a separate clickwrap / ToS? Any carve-out for classic recipes we did not invent?

### 6. Beta-tester email

File: `privacy/BETA-TESTER-EMAIL.md`

Ask: safe to send to invitees? Missing clauses?

### 7. Fonts (worldwide)

Files: `fonts/`

Inter and Bebas Neue are **self-hosted SIL OFL** files in the game bundle. The live page **does not** call Google Fonts (no visitor IP to Google).

Ask: OFL embedding ok? Any extra notice in the app?

## C. What is *not* in this pack

- Source code, database, or secrets
- Full UX audit (except the legal rows summarized above)
- Horse/K9/ape mock PNGs (not live; say if you want those stills)

## D. Product facts

- Static web game on GitHub Pages; backend is Supabase (email OTP, Postgres, RLS).
- Closed beta: allowlisted emails in `public.beta_testers`.
- Local / Playwright play stays anonymous Auth.
- Operator placeholder: DAG.com operating DAG Tails.
