# In-house trademark / publicity flags

**Not legal advice.** Copied from the engineering watchlist so counsel can see what the team is already treating as risk.

## Ship-stoppers (do not add; keep out of live art)

- **top-gun** — Paramount / US Navy marks. Do not ship patches, name tapes, or study art. Safer: Quarantine the unused jacket study; invent original patches.
- **ducktales** — Disney live Class 9 DuckTales registrations. Closest famous entertainment mark to the painted wordmark. Safer: Redesign the live wordmark away from gold brush + teal 3D + feather underline.
- **dark-n-stormy** — Gosling Brothers live USPTO mark; they have sued over the name. Safer: Dark Storm / Storm Highball. Strip Gosling lore.
- **painkiller** — Pusser's live marks for the cocktail and bar services. Safer: Island Soother. Strip Pusser's / Soggy Dollar lore.
- **el-floridita** — Real operating Havana landmark plus estate-controlled Hemingway name/likeness. Safer: Invented Havana rum bar. No Hemingway.
- **vans-stripe** — Wavy white sneaker sidestripe is a well-known Vans trademark (also on live Ace). Safer: Recolor or drop the wave on Ace / hoodie / jacket shoes.

## High (rename / redraw before a commercial launch unless counsel says otherwise)

- **aperol-campari** — Campari Group house marks, including APEROL SPRITZ in drinks/hospitality. Safer: Drink: Spritz / Piazza Spritz. Ingredients: bitter orange aperitivo, red bitter.
- **baby-guinness** — Diageo GUINNESS mark. The shot contains no Guinness. Safer: Baby Stout / Mini Pint.
- **cinderella** — Disney character mark on the kids path. Safer: Midnight Cooler / Ballroom Fizz.
- **shirley-temple** — Celebrity name; Temple sued over bottled use. A kids game is closer to a product than a bar menu. Safer: Cherry Fizz.
- **roy-rogers** — Celebrity-named mocktail on the kids path. Safer: Cola Cherry.
- **ray-ban** — Ray-Ban Aviator trade dress; jacket study may show a circled-B brandlet. Safer: Change frame shape; no temple/lens logo.
- **bacardi-tails** — Bacardi Madrid IR 1572190 is two feathers + the word TAILS (cl. 32/33). Safer: Watch merch/mixers. Do not lean harder into feather+TAILS on drinks goods.
- **disney-paramount** — Famous entertainment houses. Any name, character, or logo use is high risk. Safer: Invent original names and art.
- **spirit-house-marks** — House spirit/soft-drink marks. Recipe use of a generic category is fine; the brand name as a bottle or title is not. Safer: Use generic category names (bourbon, vodka, cola).

## Medium (usually ok as a recipe name; watch merch and logos)

- **sazerac-company** — IBA classic and Sazerac Company marks for whisky/bars/recipe sites. Safer: OK as a recipe name; avoid merch that says SAZERAC.
- **godfather** — Cocktail widely understood to ride the Paramount film. Safer: Word-only recipe name is common; no puppet-hand logo or movie type.
- **aviation-gin** — IBA cocktail name is common; Aviation American Gin is a living brand. Safer: Fine as a drink title if that bottle is not shown.
- **house-tied-classics** — Singapore Sling / Mai Tai / Bellini houses, or a liqueur house mark. Safer: Keep as generic recipes. Do not claim invention or use house logos.
- **angostura** — House bitters mark. Common as a generic bar term, still a brand. Safer: Aromatic bitters if you want zero house-name use.

## Names the team is currently keeping as in-game recipe / venue titles

- Negroni
- Americano
- Boulevardier
- Sazerac
- Godfather
- Mai Tai
- Singapore Sling
- Aviation
- Sex on the Beach
- Daiquiri
- Cuba Libre
- Mojito
- Shirley Temple
- Roy Rogers
- Jamaican Mule
- Bahama Mama
- Garibaldi
- Sidecar
- Pussyfoot
- Casa Caña
- Red Bitter
- Bitter Orange Aperitivo
