# Live catalog names

Extracted from `data.js` for clearance. Invented venue/master names are listed with city.

## Venues (18+ journey)

| Name | City | Country | Kind | Master (invented) |
| --- | --- | --- | --- | --- |
| The Snug | London | United Kingdom | Gin pub | Old Tom |
| Zavod | Moscow | Russia | Vodka bar | Irina Frost |
| La Cantina | Mexico City | Mexico | Cantina | Don Raúl |
| Aperitivo Piazza | Milan | Italy | Aperitivo bar | Signora Rosa |
| Casa Caña | Havana | Cuba | Rum bar | Constanza |
| The Speakeasy | New Orleans | United States | Speakeasy | Silas Crowe |
| Le Boudoir | Paris | France | Champagne salon | Madame Colette |
| The Still | Edinburgh | Scotland | Whisky bar | Hamish MacPeck |
| Sunset Tiki | Waikiki | Polynesia | Tiki bar | Koa |

## Venues (under-18 mocktail path)

| Name | City | Country | Kind | Master (invented) |
| --- | --- | --- | --- | --- |
| Soda Fountain | Hometown | United States | Soda shop | Miss Cherry |
| Juice Bar | Portland | United States | Juice bar | Green Jay |
| Beach Shack | San Juan | Caribbean | Beach shack | Sandy |

## Recipes (journey + mixology catalogue)

| Name |
| --- |
| Gin & Tonic |
| Screwdriver |
| Cuba Libre |
| Moscow Mule |
| Jamaican Mule |
| Tequila Sunrise |
| Paloma |
| Mimosa |
| Bellini |
| Kir Royale |
| Black Russian |
| White Russian |
| Americano |
| Garibaldi |
| Tom Collins |
| Sex on the Beach |
| Blue Lagoon |
| Bramble |
| Bloody Mary |
| Godfather |
| Long Island Iced Tea |
| Daiquiri |
| Margarita |
| Gimlet |
| Whiskey Sour |
| Amaretto Sour |
| Cosmopolitan |
| French 75 |
| Clover Club |
| Pisco Sour |
| Aviation |
| Corpse Reviver #2 |
| Negroni |
| Boulevardier |
| Sidecar |
| Rob Roy |
| Rusty Nail |
| Old Fashioned |
| Manhattan |
| Sazerac |
| Dry Martini |
| Mojito |
| Caipirinha |
| Mint Julep |
| Mai Tai |
| Bahama Mama |
| Singapore Sling |
| Hurricane |
| Piña Colada |
| Espresso Martini |
| Penicillin |

## Extra classic titles (detection list)

_None beyond the recipe list._

## Ingredients

| Name | Category |
| --- | --- |
| White Rum | Spirits |
| Dark Rum | Spirits |
| Gin | Spirits |
| Vodka | Spirits |
| Citron Vodka | Spirits |
| Tequila | Spirits |
| Mezcal | Spirits |
| Bourbon | Spirits |
| Rye Whiskey | Spirits |
| Cognac | Spirits |
| Triple Sec | Liqueurs |
| Red Bitter | Liqueurs |
| Bitter Orange Aperitivo | Liqueurs |
| Sweet Vermouth | Liqueurs |
| Dry Vermouth | Liqueurs |
| Coffee Liqueur | Liqueurs |
| Amaretto | Liqueurs |
| Maraschino | Liqueurs |
| Elderflower Liqueur | Liqueurs |
| Lime Juice | Juices |
| Lemon Juice | Juices |
| Grapefruit Juice | Juices |
| Cranberry Juice | Juices |
| Orange Juice | Juices |
| Pineapple Juice | Juices |
| Soda Water | Mixers |
| Tonic Water | Mixers |
| Cola | Mixers |
| Ginger Beer | Mixers |
| Ginger Ale | Mixers |
| Prosecco | Mixers |
| Espresso | Mixers |
| Sugar Syrup | Syrups & Sweet |
| Grenadine | Syrups & Sweet |
| Honey Syrup | Syrups & Sweet |
| Agave Syrup | Syrups & Sweet |
| Orgeat (Almond) | Syrups & Sweet |
| Angostura Bitters | Bitters |
| Orange Bitters | Bitters |
| Egg White | Dairy & Egg |
| Cream | Dairy & Egg |
| Coconut Cream | Dairy & Egg |
| Mint Leaves | Herbs & Spice |
| Hot Sauce | Herbs & Spice |
| Cachaça | Spirits |
| Scotch Whisky | Spirits |
| Pisco | Spirits |
| Absinthe | Spirits |
| Peach Schnapps | Liqueurs |
| Blue Curaçao | Liqueurs |
| Crème de Cassis | Liqueurs |
| Crème de Violette | Liqueurs |
| Cherry Liqueur | Liqueurs |
| Raspberry Liqueur | Liqueurs |
| Drambuie | Liqueurs |
| Irish Cream | Liqueurs |
| Tomato Juice | Juices |
| Passion Fruit Purée | Juices |
| Peach Purée | Juices |
| Raspberry Syrup | Syrups & Sweet |

## Glasses

- Rocks (Old Fashioned)
- Highball
- Collins
- Coupe
- Martini
- Margarita
- Hurricane
- Wine
- Shot

## Mixologist judges (live duck roster)

| Name | Title | Breed |
| --- | --- | --- |
| Vera Sterling | Silver-screen martini grande dame | Silver Appleyard cross (silver-screen white) |
| Rina Patel | Upright Indian Runner with a sweet tooth | Indian Runner |
| Sal Delacroix | Rebel sour specialist | Khaki Campbell (street-rebel cut) |
| Beatrix Bardin | Velvet-dark amaro icon | Cayuga (velvet black) |
| Maggie Pike | Pied Magpie duck of the spritz set | Magpie |
| Tommy Soleil | Tropical resort showman | Rouen (tropical resort cut) |
| Bianca Vale | Precision fashion-editor palate | Call Duck (precision line) |
| Bruno Ryder | Aviator rogue who likes it strong | Muscovy (aviator cut) |
| Rio Mendes | Muscovy host who loves a crowd | Muscovy |
| Cyrus Kane | Severe black-book critic | Black East Indie |
| Marcus Vane | Velvet-voiced Cayuga lounge crooner | Cayuga |
| Freya Lindqvist | Ice-cool Nordic purist | White Pekin (Nordic line) |
| Anika Rao | Bold celebrity-chef palate | Chocolate Rouen |
| Valentina Cruz | Blue Swedish telenovela showstopper | Blue Swedish |
| Amir Farouk | Khaki Campbell hospitality mogul | Khaki Campbell |
| Hana Yoshida | Mandarin duck pop sensation | Mandarin duck |
| Jax Holloway | Iridescent Wood Duck aromatics geek | Wood Duck (Aix sponsa) |
| Lili Agung | Bali-crested floral showrunner | Bali duck (crested) |
| Otto Brandt | Saxony beer-hall bitters sage | Saxony |
| Sue Appleyard | Silver Appleyard orchard host | Silver Appleyard |
