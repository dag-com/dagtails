# Live brand stills

These are the files actually used on hub / splash / rank-up. Mocks (horses, K9s, apes, unused jacket studies) are **not** included.

- `dag-tails-logo.png` — current wordmark
- `duck-hub-mascot.png` — hoodie guide
- `duck-hub-mascot-jacket.png` — service-jacket rank
- `duck-hub-mascot-ace.png` — Ace bomber. Generic gold aviators (no temple logo). Plain cupsole sneakers (foxing line only, no jazz stripe).
